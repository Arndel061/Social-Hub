<?php
session_start();
require_once 'config/database.php';

// Ensure user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// Fetch statuses
$stmt = $conn->prepare("
    SELECT status.id, status.user_id, status.content, status.created_at, users.username, users.profile_pic 
    FROM status 
    JOIN users ON status.user_id = users.id
    ORDER BY status.created_at DESC
");
$stmt->execute();
$result = $stmt->get_result();
$statuses = $result->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Status Updates - Pixeo</title>
<link rel="stylesheet" href="css/status.css">
</head>
<body>
<div class="status-container">
    <h1>Status Updates</h1>

    <!-- New Status Form -->
    <form action="php/upload_status.php" method="POST" class="new-status-form">
        <input type="text" name="content" placeholder="What's on your mind?" required>
        <button type="submit">Post Status</button>
    </form>

    <!-- Display statuses -->
    <?php if (empty($statuses)): ?>
        <p>No statuses yet. Be the first to update!</p>
    <?php else: ?>
        <?php foreach ($statuses as $status): ?>
            <div class="status-card">
                <img src="<?= htmlspecialchars($status['profile_pic']) ?>" alt="Profile" class="profile-pic">
                <div class="status-info">
                    <span class="username"><?= htmlspecialchars($status['username']) ?></span>
                    <span class="time"><?= $status['created_at'] ?></span>
                    <p><?= htmlspecialchars($status['content']) ?></p>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>

    <div class="links">
        <a href="dashboard.php">Back to Dashboard</a> |
        <a href="logout.php">Logout</a>
    </div>
</div>
</body>
</html>
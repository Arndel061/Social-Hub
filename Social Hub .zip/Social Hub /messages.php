<?php
session_start();
require_once 'config/database.php';

// Ensure user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// Fetch user's chat list
$stmt = $conn->prepare("SELECT DISTINCT sender_id, receiver_id FROM messages WHERE sender_id = ? OR receiver_id = ?");
$stmt->bind_param("ii", $user_id, $user_id);
$stmt->execute();
$result = $stmt->get_result();
$chats = $result->fetch_all(MYSQLI_ASSOC);

?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Messages - Pixeo</title>
<link rel="stylesheet" href="css/chat.css">
</head>
<body>
<div class="messages-container">
    <h1>Messages</h1>

    <div class="chat-list">
        <h2>Chats</h2>
        <ul>
            <?php foreach ($chats as $chat): 
                $other_id = ($chat['sender_id'] == $user_id) ? $chat['receiver_id'] : $chat['sender_id'];
                // Fetch other user info
                $stmt2 = $conn->prepare("SELECT username FROM users WHERE id = ?");
                $stmt2->bind_param("i", $other_id);
                $stmt2->execute();
                $result2 = $stmt2->get_result();
                $other_user = $result2->fetch_assoc();
            ?>
            <li><a href="?chat_with=<?= $other_id ?>"><?= htmlspecialchars($other_user['username']) ?></a></li>
            <?php endforeach; ?>
        </ul>
    </div>

    <div class="chat-window">
        <?php
        if (isset($_GET['chat_with'])) {
            $chat_with = (int) $_GET['chat_with'];
            // Fetch messages between users
            $stmt3 = $conn->prepare("SELECT * FROM messages WHERE (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?) ORDER BY created_at ASC");
            $stmt3->bind_param("iiii", $user_id, $chat_with, $chat_with, $user_id);
            $stmt3->execute();
            $messages = $stmt3->get_result()->fetch_all(MYSQLI_ASSOC);
        ?>
        <h3>Chat with <?= htmlspecialchars($other_user['username']) ?></h3>
        <div class="messages">
            <?php foreach ($messages as $msg): ?>
                <p class="<?= ($msg['sender_id'] == $user_id) ? 'sent' : 'received' ?>"><?= htmlspecialchars($msg['message']) ?> <span class="time"><?= $msg['created_at'] ?></span></p>
            <?php endforeach; ?>
        </div>
        <form method="POST" action="php/send_message.php">
            <input type="hidden" name="receiver_id" value="<?= $chat_with ?>">
            <input type="text" name="message" placeholder="Type a message..." required>
            <button type="submit">Send</button>
        </form>
        <?php else: ?>
            <p>Select a chat from the list.</p>
        <?php endif; ?>
    </div>

    <div class="links">
        <a href="dashboard.php">Back to Dashboard</a> |
        <a href="logout.php">Logout</a>
    </div>
</div>
</body>
</html>
<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
$username = $_SESSION['username'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Social Hub ß</title>
    <link rel="stylesheet" href="css/dashboard.css">
</head>
<body>
    <header>
        <div class="header-container">
            <h1>ß Social Hub</h1>
            <nav>
                <a href="profile.php">Profile</a>
                <a href="settings.php">Settings</a>
                <a href="notifications.php">Notifications</a>
                <a href="messages.php">Messages</a>
                <a href="logout.php">Logout</a>
            </nav>
        </div>
    </header>

    <main>
        <section class="welcome">
            <h2>Welcome, <?= htmlspecialchars($username) ?>!</h2>
            <p>Stay connected, play games, watch videos, and explore updates from around the world!</p>
        </section>

        <section class="dashboard-sections">
            <div class="dashboard-card" id="news">
                <h3>News & Updates 📰</h3>
                <p>Latest news from all over the globe.</p>
            </div>
            <div class="dashboard-card" id="groups">
                <h3>Groups 👥</h3>
                <p>Create or join groups and communities.</p>
            </div>
            <div class="dashboard-card" id="pages">
                <h3>Pages 📄</h3>
                <p>Follow pages of interest.</p>
            </div>
            <div class="dashboard-card" id="games">
                <h3>Games 🎮</h3>
                <p>Play fun and interactive games with friends.</p>
            </div>
            <div class="dashboard-card" id="status">
                <h3>Status Updates 💬</h3>
                <p>Share what’s happening with your friends.</p>
            </div>
            <div class="dashboard-card" id="videos">
                <h3>Videos 📹</h3>
                <p>Watch or upload videos from your feed.</p>
            </div>
            <div class="dashboard-card" id="notifications">
                <h3>Notifications 🔔</h3>
                <p>See what’s new and trending around you.</p>
            </div>
            <div class="dashboard-card" id="messages">
                <h3>Messages 💌</h3>
                <p>Chat with friends in real-time.</p>
            </div>
        </section>
    </main>

    <script src="js/main.js" defer></script>
    <script src="js/feed.js" defer></script>
    <script src="js/chat.js" defer></script>
    <script src="js/notifications.js" defer></script>
    <script src="js/video.js" defer></script>
    <script src="js/games.js" defer></script>
</body>
</html>
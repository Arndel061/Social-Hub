<?php
session_start();
require_once 'config/database.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$message = '';

// Fetch user data
$stmt = $conn->prepare("SELECT username, email, profile_pic, status FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

// Handle profile update
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username'] ?? '');
    $status = trim($_POST['status'] ?? '');
    $profile_pic = $user['profile_pic'];

    // Handle profile picture upload
    if (isset($_FILES['profile_pic']) && $_FILES['profile_pic']['error'] == 0) {
        $target_dir = "uploads/images/";
        $file_name = basename($_FILES['profile_pic']['name']);
        $target_file = $target_dir . $file_name;
        move_uploaded_file($_FILES['profile_pic']['tmp_name'], $target_file);
        $profile_pic = $target_file;
    }

    // Update in DB
    $stmt = $conn->prepare("UPDATE users SET username = ?, status = ?, profile_pic = ? WHERE id = ?");
    $stmt->bind_param("sssi", $username, $status, $profile_pic, $user_id);
    if ($stmt->execute()) {
        $message = "Profile updated successfully!";
        // Refresh user data
        $stmt = $conn->prepare("SELECT username, email, profile_pic, status FROM users WHERE id = ?");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();
    } else {
        $message = "Update failed. Try again!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile - Pixeo</title>
    <link rel="stylesheet" href="css/profile.css">
</head>
<body>
    <div class="profile-container">
        <h1>Your Profile</h1>

        <?php if ($message): ?>
            <p class="success-message"><?= htmlspecialchars($message) ?></p>
        <?php endif; ?>

        <div class="profile-info">
            <img src="<?= htmlspecialchars($user['profile_pic'] ?: 'img/profile1.jpg') ?>" alt="Profile Picture" class="profile-pic">
            <p><strong>Username:</strong> <?= htmlspecialchars($user['username']) ?></p>
            <p><strong>Email:</strong> <?= htmlspecialchars($user['email']) ?></p>
            <p><strong>Status:</strong> <?= htmlspecialchars($user['status']) ?></p>
        </div>

        <form action="" method="POST" enctype="multipart/form-data">
            <label>Username:</label>
            <input type="text" name="username" value="<?= htmlspecialchars($user['username']) ?>" required>

            <label>Status:</label>
            <input type="text" name="status" value="<?= htmlspecialchars($user['status']) ?>">

            <label>Change Profile Picture:</label>
            <input type="file" name="profile_pic">

            <button type="submit">Update Profile</button>
        </form>

        <div class="links">
            <a href="dashboard.php">Back to Dashboard</a> |
            <a href="logout.php">Logout</a>
        </div>
    </div>
</body>
</html>
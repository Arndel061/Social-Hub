<?php
session_start();
if (isset($_SESSION['user_id'])) {
    header("Location: dashboard.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login - Social Hub ß</title>
<link rel="stylesheet" href="css/login.css">
</head>
<body>
<div class="login-container">
    <h1>Login to Social Hub ß</h1>

    <?php if(isset($_SESSION['error'])): ?>
        <p class="error-message"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></p>
    <?php endif; ?>

    <?php if(isset($_SESSION['success'])): ?>
        <p class="success-message"><?php echo $_SESSION['success']; unset($_SESSION['success']); ?></p>
    <?php endif; ?>

    <form method="POST" action="php/auth.php">
        <input type="hidden" name="action" value="login">
        <input type="text" name="username" placeholder="Username" required>
        <input type="password" name="password" placeholder="Password" required>
        
        <button type="submit">Login</button>
    </form>

    <div class="links">
        <a href="php/forgot_password.php">Forgot Password?</a> |
        <a href="register.php">Sign Up</a>
    </div>
</div>
</body>
</html>
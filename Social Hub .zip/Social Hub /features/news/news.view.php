<?php
session_start();
require_once 'news_controller.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>News - Social Hub ß</title>
    <link rel="stylesheet" href="../../css/news.css">
</head>
<body>
    <div class="news-container">
        <h1>News & Updates</h1>

        <section class="create-news">
            <h2>Post News</h2>
            <form action="news_controller.php" method="POST">
                <input type="hidden" name="action" value="create_news">
                <input type="text" name="title" placeholder="Title" required>
                <textarea name="content" placeholder="Content" required></textarea>
                <button type="submit">Post</button>
            </form>
        </section>

        <section class="all-news">
            <h2>Latest News</h2>
            <ul>
                <?php foreach ($news_list as $news): ?>
                    <li>
                        <h3><?= htmlspecialchars($news['title']) ?></h3>
                        <p><?= htmlspecialchars($news['content']) ?></p>
                        <small>Posted by <?= htmlspecialchars($news['author']) ?></small>
                    </li>
                <?php endforeach; ?>
            </ul>
        </section>
    </div>
</body>
</html>
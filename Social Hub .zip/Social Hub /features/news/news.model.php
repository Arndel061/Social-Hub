<?php
require_once '../../config/database.php';

/**
 * Fetch all news articles
 */
function getAllNews() {
    global $conn;
    $stmt = $conn->prepare("SELECT n.*, u.username AS author FROM news n JOIN users u ON n.author_id = u.id ORDER BY n.id DESC");
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_all(MYSQLI_ASSOC);
}

/**
 * Create a news post
 */
function createNews($title, $content, $author_id) {
    global $conn;
    $stmt = $conn->prepare("INSERT INTO news (title, content, author_id) VALUES (?, ?, ?)");
    $stmt->bind_param("ssi", $title, $content, $author_id);
    return $stmt->execute();
}
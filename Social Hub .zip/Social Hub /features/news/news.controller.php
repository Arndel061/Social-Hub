<?php
session_start();
require_once 'news_model.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../../dashboard.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// CREATE NEWS POST
if (isset($_POST['action']) && $_POST['action'] === 'create_news') {
    $title = trim($_POST['title'] ?? '');
    $content = trim($_POST['content'] ?? '');
    if ($title && $content) {
        createNews($title, $content, $user_id);
    }
    header("Location: news_view.php");
    exit();
}

// FETCH ALL NEWS
$news_list = getAllNews();
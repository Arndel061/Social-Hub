<?php
session_start();
require_once 'chat_controller.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chat - Social Hub ß</title>
    <link rel="stylesheet" href="../../css/chat.css">
</head>
<body>
    <div class="chat-container">

        <div class="user-list">
            <h3>Friends</h3>
            <ul>
                <?php foreach ($users as $user): ?>
                    <li>
                        <a href="chat_view.php?friend_id=<?= $user['id'] ?>">
                            <?= htmlspecialchars($user['username']) ?>
                        </a>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>

        <div class="chat-box">
            <?php if ($friend_id > 0): ?>
                <h3>Chat with <?= htmlspecialchars($users[array_search($friend_id, array_column($users, 'id'))]['username'] ?? 'User') ?></h3>
                <div class="messages">
                    <?php foreach ($messages as $msg): ?>
                        <p class="<?= $msg['sender_id'] == $user_id ? 'sent' : 'received' ?>">
                            <?= htmlspecialchars($msg['message']) ?>
                        </p>
                    <?php endforeach; ?>
                </div>

                <form action="chat_controller.php" method="POST">
                    <input type="hidden" name="action" value="send_message">
                    <input type="hidden" name="receiver_id" value="<?= $friend_id ?>">
                    <input type="text" name="message" placeholder="Type a message..." required>
                    <button type="submit">Send</button>
                </form>
            <?php else: ?>
                <p>Select a friend to start chatting!</p>
            <?php endif; ?>
        </div>

    </div>
</body>
</html>
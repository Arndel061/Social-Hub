<?php
session_start();
require_once 'chat_model.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../../dashboard.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// SEND MESSAGE
if (isset($_POST['action']) && $_POST['action'] == 'send_message') {
    $receiver_id = intval($_POST['receiver_id'] ?? 0);
    $message = trim($_POST['message'] ?? '');

    if ($receiver_id > 0 && !empty($message)) {
        sendMessage($user_id, $receiver_id, $message);
    }

    header("Location: chat_view.php?friend_id=$receiver_id");
    exit();
}

// VIEW CHAT
$friend_id = intval($_GET['friend_id'] ?? 0);
$messages = [];
if ($friend_id > 0) {
    $messages = getMessages($user_id, $friend_id);
}

// FETCH USERS FOR CHAT LIST
$users = getAllUsers($user_id);
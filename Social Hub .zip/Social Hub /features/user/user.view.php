<?php
session_start();
require_once 'user_controller.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile - Social Hub ß</title>
    <link rel="stylesheet" href="../../css/profile.css">
    <script src="../../js/profile.js" defer></script>
</head>
<body>
    <div class="profile-container">
        <h1>Your Profile</h1>

        <?php if ($success): ?>
            <p class="success-message"><?= htmlspecialchars($success) ?></p>
        <?php endif; ?>
        <?php if ($error): ?>
            <p class="error-message"><?= htmlspecialchars($error) ?></p>
        <?php endif; ?>

        <form action="user_controller.php" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="action" value="update_profile">

            <label>Username:</label>
            <input type="text" name="username" value="<?= htmlspecialchars($user['username']) ?>" required>

            <label>Email:</label>
            <input type="email" name="email" value="<?= htmlspecialchars($user['email']) ?>" required>

            <label>Profile Picture:</label>
            <input type="file" name="profile_pic" accept="image/*">

            <?php if ($user['profile_pic']): ?>
                <div class="current-pic">
                    <img src="../../<?= $user['profile_pic'] ?>" alt="Profile Picture" width="100">
                </div>
            <?php endif; ?>

            <button type="submit">Update Profile</button>
        </form>
    </div>
</body>
</html>
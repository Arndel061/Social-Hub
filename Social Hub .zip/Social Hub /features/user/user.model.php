<?php
require_once '../../config/database.php';

/**
 * Get user by ID
 */
function getUserById($user_id) {
    global $conn;
    $stmt = $conn->prepare("SELECT id, username, email, profile_pic FROM users WHERE id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    return $stmt->get_result()->fetch_assoc();
}

/**
 * Update user profile
 */
function updateUserProfile($user_id, $username, $email, $profile_pic = null) {
    global $conn;

    if ($profile_pic) {
        $stmt = $conn->prepare("UPDATE users SET username = ?, email = ?, profile_pic = ? WHERE id = ?");
        $stmt->bind_param("sssi", $username, $email, $profile_pic, $user_id);
    } else {
        $stmt = $conn->prepare("UPDATE users SET username = ?, email = ? WHERE id = ?");
        $stmt->bind_param("ssi", $username, $email, $user_id);
    }

    return $stmt->execute();
}
<?php
session_start();
require_once 'user_model.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../../login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$user = getUserById($user_id);

$success = '';
$error = '';

// UPDATE PROFILE
if (isset($_POST['action']) && $_POST['action'] === 'update_profile') {
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $profile_pic = null;

    // Handle profile picture upload
    if (!empty($_FILES['profile_pic']['name'])) {
        $target_dir = "../../uploads/images/";
        $target_file = $target_dir . basename($_FILES["profile_pic"]["name"]);
        if (move_uploaded_file($_FILES["profile_pic"]["tmp_name"], $target_file)) {
            $profile_pic = "uploads/images/" . basename($_FILES["profile_pic"]["name"]);
        } else {
            $error = "Failed to upload profile picture!";
        }
    }

    if (!$error) {
        if (updateUserProfile($user_id, $username, $email, $profile_pic)) {
            $success = "Profile updated successfully!";
            $user = getUserById($user_id); // Refresh user data
        } else {
            $error = "Failed to update profile!";
        }
    }
}
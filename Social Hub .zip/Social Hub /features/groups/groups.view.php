<?php
session_start();
require_once 'groups_controller.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Groups - Social Hub ß</title>
    <link rel="stylesheet" href="../../css/groups.css">
</head>
<body>
    <div class="groups-container">
        <h1>Groups</h1>

        <section class="create-group">
            <h2>Create a New Group</h2>
            <form action="groups_controller.php" method="POST">
                <input type="hidden" name="action" value="create_group">
                <input type="text" name="name" placeholder="Group Name" required>
                <textarea name="description" placeholder="Group Description"></textarea>
                <button type="submit">Create</button>
            </form>
        </section>

        <section class="all-groups">
            <h2>All Groups</h2>
            <ul>
                <?php foreach ($groups as $group): ?>
                    <li>
                        <strong><?= htmlspecialchars($group['name']) ?></strong> by <?= htmlspecialchars($group['creator']) ?>
                        <p><?= htmlspecialchars($group['description']) ?></p>
                        <?php if (!isUserInGroup($group['id'], $user_id)): ?>
                            <a href="groups_controller.php?join_group_id=<?= $group['id'] ?>">Join Group</a>
                        <?php else: ?>
                            <span>Joined ✅</span>
                        <?php endif; ?>
                    </li>
                <?php endforeach; ?>
            </ul>
        </section>
    </div>
</body>
</html>
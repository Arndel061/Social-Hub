<?php
session_start();
require_once 'groups_model.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../../dashboard.php");
    exit();
}

$user_id = $_SESSION['user_id']'];

// CREATE GROUP
if (isset($_POST['action']) && $_POST['action'] === 'create_group') {
    $name = trim($_POST['name'] ?? '');
    $description = trim($_POST['description'] ?? '');

    if ($name) {
        createGroup($name, $description, $user_id);
    }
    header("Location: groups_view.php");
    exit();
}

// JOIN GROUP
if (isset($_GET['join_group_id'])) {
    $group_id = intval($_GET['join_group_id']);
    if (!isUserInGroup($group_id, $user_id)) {
        joinGroup($group_id, $user_id);
    }
    header("Location: groups_view.php");
    exit();
}

// FETCH GROUPS
$groups = getAllGroups();
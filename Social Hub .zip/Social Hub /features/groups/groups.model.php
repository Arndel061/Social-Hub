<?php
require_once '../../config/database.php';

/**
 * Create a new group
 */
function createGroup($name, $description, $creator_id) {
    global $conn;
    $stmt = $conn->prepare("INSERT INTO groups (name, description, creator_id) VALUES (?, ?, ?)");
    $stmt->bind_param("ssi", $name, $description, $creator_id);
    return $stmt->execute();
}

/**
 * Get all groups
 */
function getAllGroups() {
    global $conn;
    $stmt = $conn->prepare("SELECT g.*, u.username AS creator FROM groups g JOIN users u ON g.creator_id = u.id ORDER BY g.id DESC");
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_all(MYSQLI_ASSOC);
}

/**
 * Join a group
 */
function joinGroup($group_id, $user_id) {
    global $conn;
    $stmt = $conn->prepare("INSERT INTO group_members (group_id, user_id) VALUES (?, ?)");
    $stmt->bind_param("ii", $group_id, $user_id);
    return $stmt->execute();
}

/**
 * Check if user is in a group
 */
function isUserInGroup($group_id, $user_id) {
    global $conn;
    $stmt = $conn->prepare("SELECT * FROM group_members WHERE group_id = ? AND user_id = ?");
    $stmt->bind_param("ii", $group_id, $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->num_rows > 0;
}
<?php
session_start();
require_once 'pages_controller.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pages - Social Hub ß</title>
    <link rel="stylesheet" href="../../css/pages.css">
</head>
<body>
    <div class="pages-container">
        <h1>Pages</h1>

        <section class="create-page">
            <h2>Create a Page</h2>
            <form action="pages_controller.php" method="POST">
                <input type="hidden" name="action" value="create_page">
                <input type="text" name="name" placeholder="Page Name" required>
                <textarea name="description" placeholder="Page Description" required></textarea>
                <button type="submit">Create Page</button>
            </form>
        </section>

        <section class="all-pages">
            <h2>All Pages</h2>
            <ul>
                <?php foreach ($pages_list as $page): ?>
                    <li>
                        <h3><?= htmlspecialchars($page['name']) ?></h3>
                        <p><?= htmlspecialchars($page['description']) ?></p>
                        <small>Created by <?= htmlspecialchars($page['owner']) ?></small>
                    </li>
                <?php endforeach; ?>
            </ul>
        </section>
    </div>
</body>
</html>
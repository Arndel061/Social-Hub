<?php
require_once '../../config/database.php';

/**
 * Fetch all pages
 */
function getAllPages() {
    global $conn;
    $stmt = $conn->prepare("SELECT p.*, u.username AS owner FROM pages p JOIN users u ON p.owner_id = u.id ORDER BY p.id DESC");
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_all(MYSQLI_ASSOC);
}

/**
 * Create a new page
 */
function createPage($name, $description, $owner_id) {
    global $conn;
    $stmt = $conn->prepare("INSERT INTO pages (name, description, owner_id) VALUES (?, ?, ?)");
    $stmt->bind_param("ssi", $name, $description, $owner_id);
    return $stmt->execute();
}
<?php
session_start();
require_once 'pages_model.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../../dashboard.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// CREATE PAGE
if (isset($_POST['action']) && $_POST['action'] === 'create_page') {
    $name = trim($_POST['name'] ?? '');
    $description = trim($_POST['description'] ?? '');
    if ($name && $description) {
        createPage($name, $description, $user_id);
    }
    header("Location: pages_view.php");
    exit();
}

// FETCH ALL PAGES
$pages_list = getAllPages();
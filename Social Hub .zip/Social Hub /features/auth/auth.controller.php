<?php
session_start();
require_once 'auth_model.php';

$error = '';
$success = '';

// LOGIN
if (isset($_POST['action']) && $_POST['action'] == 'login') {
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $user = getUserByUsername($username);

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        header("Location: ../../dashboard.php"); // redirect to root dashboard
        exit();
    } else {
        $error = "Invalid username or password!";
        $_SESSION['error'] = $error;
        header("Location: auth_view.php"); // send back to view
        exit();
    }
}

// REGISTER
if (isset($_POST['action']) && $_POST['action'] == 'register') {
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';

    if ($password !== $confirm) {
        $error = "Passwords do not match!";
    } elseif (getUserByUsername($username) || getUserByEmail($email)) {
        $error = "Username or Email already exists!";
    } else {
        if (createUser($username, $email, $password)) {
            $success = "Registration successful! You can now login.";
        } else {
            $error = "Something went wrong!";
        }
    }

    $_SESSION['error'] = $error;
    $_SESSION['success'] = $success;
    header("Location: auth_view.php"); // redirect back to view
    exit();
}
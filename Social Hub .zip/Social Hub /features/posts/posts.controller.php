<?php
session_start();
require_once 'posts_model.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../../dashboard.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// CREATE POST
if (isset($_POST['action']) && $_POST['action'] === 'create_post') {
    $content = trim($_POST['content'] ?? '');
    if ($content) {
        createPost($user_id, $content);
    }
    header("Location: posts_view.php");
    exit();
}

// LIKE POST
if (isset($_POST['action']) && $_POST['action'] === 'like_post') {
    $post_id = intval($_POST['post_id'] ?? 0);
    if ($post_id) {
        likePost($post_id, $user_id);
    }
    header("Location: posts_view.php");
    exit();
}

// FETCH ALL POSTS
$posts_list = getAllPosts();
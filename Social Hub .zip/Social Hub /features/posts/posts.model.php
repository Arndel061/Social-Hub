<?php
require_once '../../config/database.php';

/**
 * Fetch all posts
 */
function getAllPosts() {
    global $conn;
    $stmt = $conn->prepare("
        SELECT p.*, u.username AS author 
        FROM posts p 
        JOIN users u ON p.user_id = u.id 
        ORDER BY p.id DESC
    ");
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_all(MYSQLI_ASSOC);
}

/**
 * Create a new post
 */
function createPost($user_id, $content) {
    global $conn;
    $stmt = $conn->prepare("INSERT INTO posts (user_id, content) VALUES (?, ?)");
    $stmt->bind_param("is", $user_id, $content);
    return $stmt->execute();
}

/**
 * Like a post
 */
function likePost($post_id, $user_id) {
    global $conn;
    $stmt = $conn->prepare("INSERT INTO likes (post_id, user_id) VALUES (?, ?)");
    $stmt->bind_param("ii", $post_id, $user_id);
    return $stmt->execute();
}
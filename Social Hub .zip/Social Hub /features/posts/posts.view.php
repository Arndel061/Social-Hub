<?php
session_start();
require_once 'posts_controller.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Posts - Social Hub ß</title>
    <link rel="stylesheet" href="../../css/posts.css">
    <script src="../../js/feed.js" defer></script>
</head>
<body>
    <div class="posts-container">
        <h1>Posts</h1>

        <section class="create-post">
            <form action="posts_controller.php" method="POST">
                <input type="hidden" name="action" value="create_post">
                <textarea name="content" placeholder="What's on your mind?" required></textarea>
                <button type="submit">Post</button>
            </form>
        </section>

        <section class="all-posts">
            <ul>
                <?php foreach ($posts_list as $post): ?>
                    <li>
                        <p><strong><?= htmlspecialchars($post['author']) ?></strong>: <?= htmlspecialchars($post['content']) ?></p>
                        <form action="posts_controller.php" method="POST">
                            <input type="hidden" name="action" value="like_post">
                            <input type="hidden" name="post_id" value="<?= $post['id'] ?>">
                            <button type="submit">Like</button>
                        </form>
                    </li>
                <?php endforeach; ?>
            </ul>
        </section>
    </div>
</body>
</html>
// Dynamically load posts (mock)
const feedContainer = document.querySelector('#feed');

function createPost(username, content) {
    const post = document.createElement('div');
    post.classList.add('post-card');
    post.innerHTML = `<h4>${username}</h4><p>${content}</p>`;
    feedContainer.prepend(post);
}

// Demo posts
createPost('Alice', 'Hello Social Hub ß!');
createPost('Bob', 'Just joined ß, excited to explore!');
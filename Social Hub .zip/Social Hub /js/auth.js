// Simple front-end form validation
document.querySelectorAll('form').forEach(form => {
    form.addEventListener('submit', e => {
        const username = form.querySelector('input[name="username"]');
        const password = form.querySelector('input[name="password"]');
        if (username && username.value.trim() === '') {
            alert('Please enter username');
            e.preventDefault();
        }
        if (password && password.value.trim() === '') {
            alert('Please enter password');
            e.preventDefault();
        }
    });
});
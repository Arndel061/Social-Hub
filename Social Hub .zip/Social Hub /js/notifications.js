// Demo notifications fetch
const notifContainer = document.querySelector('#notifications-container');

function addNotification(text) {
    const notif = document.createElement('div');
    notif.classList.add('notification-card');
    notif.textContent = text;
    notifContainer.prepend(notif);
}

// Simulate notifications
setInterval(() => {
    addNotification('New user joined Social Hub ß!');
}, 20000);
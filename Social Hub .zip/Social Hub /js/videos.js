const videos = document.querySelectorAll('.video-card video');

videos.forEach(video => {
    video.addEventListener('click', () => {
        if(video.paused) video.play();
        else video.pause();
    });

    // Progress bar
    const progress = video.parentElement.querySelector('.video-progress');
    if(progress){
        video.addEventListener('timeupdate', () => {
            progress.value = (video.currentTime / video.duration) * 100;
        });
    }
});
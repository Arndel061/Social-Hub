// Simulate score submission
function submitScore(game, score) {
    console.log(`Game: ${game}, Score: ${score}`);
    // Here, you would send score to server via AJAX
}

// Example
document.querySelectorAll('.play-game').forEach(btn => {
    btn.addEventListener('click', () => {
        const score = Math.floor(Math.random() * 100);
        submitScore(btn.dataset.game, score);
        alert(`You scored ${score} points!`);
    });
});
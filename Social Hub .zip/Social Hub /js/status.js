const statusForm = document.querySelector('#status-form');
const statusFeed = document.querySelector('#status-feed');

if(statusForm) {
    statusForm.addEventListener('submit', e => {
        e.preventDefault();
        const input = statusForm.querySelector('input[name="status"]');
        if(input.value.trim() !== '') {
            const status = document.createElement('div');
            status.classList.add('status-card');
            status.textContent = `You: ${input.value}`;
            statusFeed.prepend(status);
            input.value = '';
        }
    });
}
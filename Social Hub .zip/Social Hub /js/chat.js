const chatForm = document.querySelector('#chat-form');
const chatBox = document.querySelector('#chat-box');

if(chatForm) {
    chatForm.addEventListener('submit', e => {
        e.preventDefault();
        const input = chatForm.querySelector('input[name="message"]');
        if(input.value.trim() !== '') {
            const msg = document.createElement('div');
            msg.classList.add('chat-message');
            msg.textContent = `You: ${input.value}`;
            chatBox.appendChild(msg);
            chatBox.scrollTop = chatBox.scrollHeight;
            input.value = '';
        }
    });
}

// Simulate incoming messages (demo)
setInterval(() => {
    if(chatBox) {
        const msg = document.createElement('div');
        msg.classList.add('chat-message', 'incoming');
        msg.textContent = 'Friend: Hello!';
        chatBox.appendChild(msg);
        chatBox.scrollTop = chatBox.scrollHeight;
    }
}, 15000);
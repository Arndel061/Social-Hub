// Edit profile demo
const editBtn = document.querySelector('#edit-profile');
const saveBtn = document.querySelector('#save-profile');

if(editBtn && saveBtn) {
    editBtn.addEventListener('click', () => {
        document.querySelectorAll('.profile-field').forEach(f => f.removeAttribute('readonly'));
    });

    saveBtn.addEventListener('click', () => {
        document.querySelectorAll('.profile-field').forEach(f => f.setAttribute('readonly', true));
        alert('Profile saved!');
    });
}
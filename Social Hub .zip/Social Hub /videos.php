<?php
session_start();
require_once 'config/database.php';

// Ensure user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Fetch all videos from database
$stmt = $conn->prepare("SELECT id, title, thumbnail, video_path, uploaded_at FROM videos ORDER BY uploaded_at DESC");
$stmt->execute();
$result = $stmt->get_result();
$videos = $result->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Video Hub - Pixeo</title>
<link rel="stylesheet" href="css/videos.css">
</head>
<body>
<div class="videos-container">
    <h1>Video Hub 📹</h1>

    <?php if (empty($videos)): ?>
        <p>No videos available yet. Upload or check back later!</p>
    <?php else: ?>
        <div class="videos-list">
            <?php foreach ($videos as $video): ?>
                <div class="video-card">
                    <video controls>
                        <source src="<?= htmlspecialchars($video['video_path']) ?>" type="video/mp4">
                        Your browser does not support the video tag.
                    </video>
                    <h3><?= htmlspecialchars($video['title']) ?></h3>
                    <p>Uploaded on <?= date('M d, Y', strtotime($video['uploaded_at'])) ?></p>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>
</body>
</html>
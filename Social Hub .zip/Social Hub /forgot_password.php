<?php
session_start();
$message = $_SESSION['success'] ?? $_SESSION['error'] ?? '';
unset($_SESSION['success'], $_SESSION['error']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password - Social Hub ß</title>
    <link rel="stylesheet" href="css/login.css">
</head>
<body>
    <div class="login-container">
        <h1>Forgot Password</h1>

        <?php if ($message): ?>
            <p class="<?= isset($_SESSION['error']) ? 'error-message' : 'success-message' ?>">
                <?= htmlspecialchars($message) ?>
            </p>
        <?php endif; ?>

        <form action="php/auth.php" method="POST">
            <input type="hidden" name="action" value="forgot_password">
            <input type="email" name="email" placeholder="Enter your email" required>
            <button type="submit">Request Reset</button>
        </form>

        <div class="links">
            Remember your password? <a href="login.php">Login here</a>
        </div>
    </div>
</body>
</html>
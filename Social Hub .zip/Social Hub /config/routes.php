<?php
// config/routes.php

// Example: simple route mapping
$routes = [
    '/' => 'index.php',
    '/login' => 'login.php',
    '/register' => 'register.php',
    '/dashboard' => 'dashboard.php',
    '/logout' => 'logout.php'
];

// Basic router
$request = $_SERVER['REQUEST_URI'];
$path = parse_url($request, PHP_URL_PATH);

if (array_key_exists($path, $routes)) {
    include __DIR__ . '/../' . $routes[$path];
} else {
    http_response_code(404);
    echo "Page not found!";
}
?>
<?php
session_start();
// If already logged in, redirect to dashboard
if (isset($_SESSION['user_id'])) {
    header("Location: dashboard.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Social Hub ß</title>
  <link rel="stylesheet" href="css/style.css">
  <script src="js/main.js" defer></script>
  <link rel="icon" href="favicon.ico" type="image/x-icon">
</head>
<body>
  <header>
    <h1 class="logo" style="text-align:center;">ß Social Hub</h1>
    <nav>
      <ul>
        <li><a href="#news">📰 News</a></li>
        <li><a href="#status">💬 Status</a></li>
        <li><a href="login.php">🔑 Login</a></li>
        <li><a href="register.php">📝 Register</a></li>
      </ul>
    </nav>
  </header>

  <main>
    <section id="news">
      <h2>Global News Updates</h2>
      <p>Stay informed with latest happenings around the world.</p>
    </section>

    <section id="status">
      <h2>Recent Status Updates</h2>
      <p>See what your friends are sharing now.</p>
    </section>

    <section id="features">
      <h2>Features</h2>
      <ul>
        <li>Groups – create and join communities</li>
        <li>Pages – follow and interact with public pages</li>
        <li>Games – play and track scores</li>
        <li>Videos – watch and share videos</li>
      </ul>
    </section>
  </main>

  <footer>
    <p>&copy; 2026 Social Hub ß. All rights reserved.</p>
    <div class="social-icons">
      <a href="#"><i class="fab fa-facebook-f"></i></a>
      <a href="#"><i class="fab fa-twitter"></i></a>
      <a href="#"><i class="fab fa-linkedin-in"></i></a>
      <a href="#"><i class="fab fa-instagram"></i></a>
    </div>
  </footer>
</body>
</html>
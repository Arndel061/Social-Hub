<?php
session_start();
require_once 'config/database.php';

// Ensure user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Fetch all games from database
$stmt = $conn->prepare("SELECT id, game_name, thumbnail, game_url FROM games ORDER BY game_name ASC");
$stmt->execute();
$result = $stmt->get_result();
$games = $result->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Games Hub - Pixeo</title>
<link rel="stylesheet" href="css/games.css">
</head>
<body>
<div class="games-container">
    <h1>Games Hub 🎮</h1>

    <?php if (empty($games)): ?>
        <p>No games available yet. Check back later or add some!</p>
    <?php else: ?>
        <div class="games-list">
            <?php foreach ($games as $game): ?>
                <div class="game-card">
                    <img src="<?= htmlspecialchars($game['thumbnail']) ?>" alt="<?= htmlspecialchars($game['game_name']) ?>">
                    <h3><?= htmlspecialchars($game['game_name']) ?></h3>
                    <a href="<?= htmlspecialchars($game['game_url']) ?>" target="_blank">Play Now ▶️</a>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>
</body>
</html>
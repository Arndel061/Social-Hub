<?php
session_start();
require_once 'config/database.php';

// Ensure user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// Fetch notifications for this user
$stmt = $conn->prepare("SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$notifications = $result->fetch_all(MYSQLI_ASSOC);

?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Notifications - Pixeo</title>
<link rel="stylesheet" href="css/notifications.css">
</head>
<body>
<div class="notifications-container">
    <h1>Your Notifications</h1>
    <?php if (empty($notifications)): ?>
        <p>No notifications yet.</p>
    <?php else: ?>
        <ul>
        <?php foreach ($notifications as $note): ?>
            <li><?= htmlspecialchars($note['message']) ?> <span class="time"><?= $note['created_at'] ?></span></li>
        <?php endforeach; ?>
        </ul>
    <?php endif; ?>
    <div class="links">
        <a href="dashboard.php">Back to Dashboard</a> |
        <a href="logout.php">Logout</a>
    </div>
</div>
</body>
</html>
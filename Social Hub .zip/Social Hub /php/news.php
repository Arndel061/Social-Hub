<?php
session_start();
require_once 'config/database.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Fetch latest news
$stmt = $conn->prepare("
    SELECT title, content, created_at 
    FROM news 
    ORDER BY created_at DESC 
    LIMIT 20
");
$stmt->execute();
$result = $stmt->get_result();
$news = $result->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>News & Updates - Pixeo</title>
<link rel="stylesheet" href="css/news.css">
</head>
<body>
<div class="news-container">
    <h1>Latest News & Updates</h1>

    <?php if (empty($news)): ?>
        <p>No news yet. Check back later!</p>
    <?php else: ?>
        <?php foreach ($news as $item): ?>
            <div class="news-card">
                <h3><?= htmlspecialchars($item['title']) ?></h3>
                <p><?= htmlspecialchars($item['content']) ?></p>
                <span class="time"><?= $item['created_at'] ?></span>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>

    <div class="links">
        <a href="dashboard.php">Back to Dashboard</a> |
        <a href="logout.php">Logout</a>
    </div>
</div>
</body>
</html>
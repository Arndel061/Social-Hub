<?php
header('Content-Type: application/json');
require_once '../config/database.php';

$sql = "SELECT id, user_id, title, video_path, created_at FROM videos ORDER BY created_at DESC";
$result = $conn->query($sql);

$videos = [];
while($row = $result->fetch_assoc()) {
    $videos[] = $row;
}

echo json_encode($videos);
<?php
session_start();
require_once 'config/database.php';

// Ensure user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// Fetch all posts with user info
$stmt = $conn->prepare("
    SELECT posts.id, posts.user_id, posts.content, posts.media, posts.created_at, users.username, users.profile_pic 
    FROM posts 
    JOIN users ON posts.user_id = users.id 
    ORDER BY posts.created_at DESC
");
$stmt->execute();
$result = $stmt->get_result();
$posts = $result->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Posts - Pixeo</title>
<link rel="stylesheet" href="css/posts.css">
</head>
<body>
<div class="posts-container">
    <h1>Posts Feed</h1>

    <!-- New Post Form -->
    <form action="php/upload_post.php" method="POST" enctype="multipart/form-data" class="new-post-form">
        <textarea name="content" placeholder="What's on your mind?" required></textarea>
        <input type="file" name="media" accept="image/*,video/*">
        <button type="submit">Post</button>
    </form>

    <!-- Display posts -->
    <?php if (empty($posts)): ?>
        <p>No posts yet. Be the first to post!</p>
    <?php else: ?>
        <?php foreach ($posts as $post): ?>
            <div class="post">
                <div class="post-header">
                    <img src="<?= htmlspecialchars($post['profile_pic']) ?>" alt="Profile" class="profile-pic">
                    <span class="username"><?= htmlspecialchars($post['username']) ?></span>
                    <span class="time"><?= $post['created_at'] ?></span>
                </div>
                <p class="post-content"><?= htmlspecialchars($post['content']) ?></p>
                <?php if (!empty($post['media'])): ?>
                    <?php 
                        $ext = pathinfo($post['media'], PATHINFO_EXTENSION);
                        if (in_array($ext, ['mp4', 'webm', 'ogg'])): ?>
                        <video controls class="post-media">
                            <source src="uploads/<?= htmlspecialchars($post['media']) ?>" type="video/<?= $ext ?>">
                        </video>
                    <?php else: ?>
                        <img src="uploads/<?= htmlspecialchars($post['media']) ?>" alt="Post Media" class="post-media">
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>

    <div class="links">
        <a href="dashboard.php">Back to Dashboard</a> |
        <a href="logout.php">Logout</a>
    </div>
</div>
</body>
</html>
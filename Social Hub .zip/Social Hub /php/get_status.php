<?php
header('Content-Type: application/json');
require_once '../config/database.php';

$sql = "SELECT s.id, s.user_id, u.username, s.status_text, s.created_at 
        FROM status s 
        JOIN users u ON s.user_id = u.id 
        ORDER BY s.created_at DESC";
$result = $conn->query($sql);

$status = [];
while($row = $result->fetch_assoc()) {
    $status[] = $row;
}

echo json_encode($status);
<?php
header('Content-Type: application/json');
require_once '../config/database.php';

$sql = "SELECT user_id, game_id, score FROM game_scores ORDER BY score DESC";
$result = $conn->query($sql);

$scores = [];
while($row = $result->fetch_assoc()) {
    $scores[] = $row;
}

echo json_encode($scores);
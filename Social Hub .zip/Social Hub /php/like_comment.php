<?php
session_start();
require_once '../config/database.php';

$postId = intval($_POST['post_id']);
$userId = $_SESSION['user_id'];

$stmt = $conn->prepare("INSERT INTO likes (user_id, post_id) VALUES (?, ?)
                        ON DUPLICATE KEY UPDATE liked_at=NOW()");
$stmt->bind_param("ii", $userId, $postId);
$stmt->execute();

echo json_encode(['status' => 'success']);
<?php
session_start();
require_once '../config/database.php';

$status = $_POST['status'] ?? '';
$userId = $_SESSION['user_id'];

$stmt = $conn->prepare("INSERT INTO status (user_id, status_text, created_at) VALUES (?, ?, NOW())");
$stmt->bind_param("is", $userId, $status);
$stmt->execute();

echo json_encode(['status' => 'success']);
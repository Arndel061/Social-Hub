<?php
session_start();
require_once 'config/database.php';

$message = '';
$token = $_GET['token'] ?? '';

if (!$token) {
    die("Invalid reset link!");
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';

    if (empty($password) || empty($confirm_password)) {
        $message = "Please fill in both fields!";
    } elseif ($password !== $confirm_password) {
        $message = "Passwords do not match!";
    } else {
        // Verify token exists
        $stmt = $conn->prepare("SELECT id FROM users WHERE reset_token = ?");
        $stmt->bind_param("s", $token);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();
            $user_id = $user['id'];

            // Hash new password
            $hashed = password_hash($password, PASSWORD_DEFAULT);

            // Update password and remove token
            $stmt = $conn->prepare("UPDATE users SET password = ?, reset_token = NULL WHERE id = ?");
            $stmt->bind_param("si", $hashed, $user_id);
            $stmt->execute();

            $message = "Password successfully updated! <a href='login.php'>Login here</a>";
        } else {
            $message = "Invalid or expired token!";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password - Pixeo</title>
    <link rel="stylesheet" href="css/login.css">
</head>
<body>
    <div class="login-container">
        <h1>Reset Password</h1>

        <?php if ($message): ?>
            <p class="success-message"><?= $message ?></p>
        <?php endif; ?>

        <form action="" method="POST">
            <input type="password" name="password" placeholder="New Password" required>
            <input type="password" name="confirm_password" placeholder="Confirm New Password" required>
            <button type="submit">Reset Password</button>
        </form>

        <div class="links">
            Remember your password? <a href="login.php">Login here</a>
        </div>
    </div>
</body>
</html>
<?php
header('Content-Type: application/json');
require_once '../config/database.php';

$sql = "SELECT p.id, p.user_id, u.username, p.content, p.created_at 
        FROM posts p 
        JOIN users u ON p.user_id = u.id 
        ORDER BY p.created_at DESC";
$result = $conn->query($sql);

$posts = [];
while($row = $result->fetch_assoc()) {
    $posts[] = $row;
}

echo json_encode($posts);
<?php
session_start();
require_once '../config/database.php';

$gameId = intval($_POST['game_id']);
$score = intval($_POST['score']);
$userId = $_SESSION['user_id'];

$stmt = $conn->prepare("INSERT INTO game_scores (user_id, game_id, score) VALUES (?, ?, ?)
                        ON DUPLICATE KEY UPDATE score=GREATEST(score, ?)");
$stmt->bind_param("iiii", $userId, $gameId, $score, $score);
$stmt->execute();

echo json_encode(['status' => 'success']);
<?php
session_start();
require_once '../config/database.php';

$userId = $_SESSION['user_id'];
$username = $_POST['username'] ?? '';
$email = $_POST['email'] ?? '';

$stmt = $conn->prepare("UPDATE users SET username=?, email=? WHERE id=?");
$stmt->bind_param("ssi", $username, $email, $userId);
$stmt->execute();

echo json_encode(['status' => 'success']);
<?php
session_start();
require_once 'config/database.php';

// Ensure user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Fetch all pages
$stmt = $conn->prepare("
    SELECT id, page_name, description, created_at 
    FROM pages 
    ORDER BY created_at DESC
");
$stmt->execute();
$result = $stmt->get_result();
$pages = $result->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Pages - Pixeo</title>
<link rel="stylesheet" href="css/pages.css">
</head>
<body>
<div class="pages-container">
    <h1>Pages</h1>

    <!-- New Page Form -->
    <form class="new-page-form" action="php/pages.php" method="post">
        <input type="text" name="page_name" placeholder="Page Name" required>
        <textarea name="description" placeholder="Page Description" required></textarea>
        <button type="submit" name="create_page">Create Page</button>
    </form>

    <!-- Pages List -->
    <?php if (empty($pages)): ?>
        <p>No pages yet. Start a page and get followers!</p>
    <?php else: ?>
        <div class="pages-list">
            <?php foreach ($pages as $page): ?>
                <div class="page-card">
                    <h3><?= htmlspecialchars($page['page_name']) ?></h3>
                    <p><?= htmlspecialchars($page['description']) ?></p>
                    <span class="time">Created: <?= $page['created_at'] ?></span>
                    <a href="follow_page.php?page_id=<?= $page['id'] ?>">Follow Page</a>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>
</body>
</html>
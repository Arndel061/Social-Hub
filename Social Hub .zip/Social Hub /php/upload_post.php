<?php
session_start();
require_once 'config/database.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $content = trim($_POST['content']);
    $media = null;

    // Handle media upload
    if (isset($_FILES['media']) && $_FILES['media']['error'] === 0) {
        $filename = time() . "_" . basename($_FILES['media']['name']);
        $target = "uploads/" . $filename;
        if (move_uploaded_file($_FILES['media']['tmp_name'], $target)) {
            $media = $filename;
        }
    }

    $stmt = $conn->prepare("INSERT INTO posts (user_id, content, media, created_at) VALUES (?, ?, ?, NOW())");
    $stmt->bind_param("iss", $user_id, $content, $media);
    $stmt->execute();
}

header("Location: posts.php");
exit;
<?php
session_start();
require_once 'config/database.php';

// Ensure user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Fetch all groups
$stmt = $conn->prepare("
    SELECT id, group_name, description, created_at 
    FROM groups 
    ORDER BY created_at DESC
");
$stmt->execute();
$result = $stmt->get_result();
$groups = $result->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Groups - Pixeo</title>
<link rel="stylesheet" href="css/groups.css">
</head>
<body>
<div class="groups-container">
    <h1>Groups</h1>

    <!-- New Group Form -->
    <form class="new-group-form" action="php/groups.php" method="post">
        <input type="text" name="group_name" placeholder="Group Name" required>
        <textarea name="description" placeholder="Group Description" required></textarea>
        <button type="submit" name="create_group">Create Group</button>
    </form>

    <!-- Groups List -->
    <?php if (empty($groups)): ?>
        <p>No groups yet. Be the first to create one!</p>
    <?php else: ?>
        <?php foreach ($groups as $group): ?>
            <div class="group-card">
                <h3><?= htmlspecialchars($group['group_name']) ?></h3>
                <p><?= htmlspecialchars($group['description']) ?></p>
                <span class="time">Created: <?= $group['created_at'] ?></span>
                <a href="join_group.php?group_id=<?= $group['id'] ?>">Join Group</a>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>
</body>
</html>
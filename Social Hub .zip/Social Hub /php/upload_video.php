<?php
session_start();
require_once '../config/database.php';

if(isset($_FILES['video'])) {
    $targetDir = "../uploads/videos/";
    $fileName = basename($_FILES['video']['name']);
    $targetFile = $targetDir . $fileName;

    if(move_uploaded_file($_FILES['video']['tmp_name'], $targetFile)) {
        $stmt = $conn->prepare("INSERT INTO videos (user_id, title, video_path, created_at) VALUES (?, ?, ?, NOW())");
        $stmt->bind_param("iss", $_SESSION['user_id'], $fileName, $targetFile);
        $stmt->execute();
        echo json_encode(['status'=>'success']);
    } else {
        echo json_encode(['status'=>'error']);
    }
}
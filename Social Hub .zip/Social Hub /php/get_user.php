<?php
header('Content-Type: application/json');
require_once '../config/database.php';

$userId = intval($_GET['user_id'] ?? 0);

$stmt = $conn->prepare("SELECT id, username, email, profile_pic FROM users WHERE id=?");
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

echo json_encode($user);